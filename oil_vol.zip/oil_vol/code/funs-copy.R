RMSE <- function(x) {
  # mean square error function given x containing
  # both actual and prediction values
  actual <- x$actual
  pred <- x$pred
  sqrt(mean((actual - pred)^2))
}
QLIKE <- function(x) {
  # only used for raw RV, not logged RV
  # quasi likehood losses
  # preferred by Patton (2009)
  # explanation see Brownlees et al. (2012)
  actual <- x$actual
  pred <- x$pred
  mean(log(pred) + (actual/pred))
}
MAE <- function(x) {
  actual <- x$actual
  pred <- x$pred
  mean(abs(actual - pred))
}

MAPE <- function(x){
  error <- (x$actual - x$pred) / x$actual
  return(mape = mean(abs(error)))
}

R2 <- function(x, rv_dt = rv_data){
  HAR_bench <- rv_data %>% 
    select(date, value) %>% 
    dplyr::slice(validation_count) %>% 
    bind_cols(harrv_bench)  %>% na.omit()
  names(HAR_bench) <- c("date", "ben_actual", "ben_pred")
  
  Model_pred <- rv_data %>% 
    select(date, value) %>% 
    dplyr::slice(validation_count) %>% 
    bind_cols(x)  %>% na.omit()
  names(Model_pred) <- c("date", "actual", "pred")
  
  model <- left_join(Model_pred, HAR_bench, by = 'date')
  
  ssx <- sum((model$actual - model$pred)^2)
  ssb <- sum((model$ben_actual - model$ben_pred)^2)
  r2 <-  1 - (ssx/ssb)
  return(r2)
}



#' Clark-West (2007) approximate normality tests for equal predictive accuracy in nested models.
#'
#' @param e.m1 Errors from model 1.
#' @param e.m2 Errors from model 2.
#' @param yf.m1 Forecasts for model 1.
#' @param yf.m2 Forecasts for model 2.
#' @return Clark-West statistics.
#' @examples
cw <- function(x) {
  
  HAR_bench <- rv_data %>% 
    select(date, value) %>% 
    dplyr::slice(validation_count) %>% 
    bind_cols(harrv_bench)  %>% na.omit()
  names(HAR_bench) <- c("date", "ben_actual", "ben_pred")
  
  Model_pred <- rv_data %>% 
    select(date, value) %>% 
    dplyr::slice(validation_count) %>% 
    bind_cols(x)  %>% na.omit()
  names(Model_pred) <- c("date", "actual", "pred")
  
  model <- left_join(Model_pred, HAR_bench, by = 'date')
  
  HAR_bench_Errors <- model$ben_actual - model$ben_pred
  
  Model_cw_Errors <- model$actual - model$pred
  
  nw <- function(y,qn){
    #input: y is a T*k vector and qn is the truncation lag
    #output: the newey west HAC covariance estimator
    #Formulas are from Hayashi
    T <- length(y)
    ybar <- rep(1,T) * ((sum(y))/T)
    dy <- y-ybar
    G0 <- t(dy) %*% dy/T
    for (j in 1:qn){
      gamma <- t(dy[(j+1):T]) %*% dy[1:T-j]/(T-1)
      G0 <- G0+(gamma+t(gamma))*(1-abs(j/qn))
    }
    return(as.numeric(G0))
  }
  
  P <- length(HAR_bench_Errors)
  froll.adj <- HAR_bench_Errors^2-(Model_cw_Errors^2-(model$ben_pred-model$pred)^2)
  varfroll.adj <- nw(froll.adj,1)
  CW <- sqrt(P)*(mean(froll.adj))/sqrt(varfroll.adj)
  pv <- 1-pnorm(CW,0,1)
  results=list(test=0, pvalue=0)
  results$test <- CW
  results$pvalue <- pv
  return(results)
}
dm <- function(x){
  
    HAR_bench <- rv_data %>% 
    select(date, value) %>% 
    dplyr::slice(validation_count) %>% 
    bind_cols(harrv_bench)  %>% na.omit()
  names(HAR_bench) <- c("date", "actual", "pred")
  HAR_bench_Errors <- HAR_bench$actual - HAR_bench$pred
  
  Model_cw <- rv_data %>% 
    select(date, value) %>% 
    dplyr::slice(validation_count) %>% 
    bind_cols(x)  %>% na.omit()
  names(Model_cw) <- c("date", "actual", "pred")
  Model_cw_Errors <- Model_cw $actual - Model_cw$pred
  
}

# my_mape <- function(x) {
#   actual <- x$actual
#   pred <- x$pred
#   mape <- mean((actual - pred)/actual, na.rm = F)
#   return(mape)
# }
# my_r2 <- function(x) {
#   actual <- x$actual
#   pred <- x$pred
#   r2 <- 1 - sum((actual-pred)^2)/sum((actual-mean(actual))^2)
#   return(r2)
# }
# mda <- function(x) {
#   actual <- x$actual
#   pred <- x$pred
#   sign_1 <- sign(diff(actual))
#   sign_2 <- sign(pred[-1] - lag(actual, 1)[-1])
#   mda <- mean(sign_1 == sign_2)
#   return(mda)
# }

rv_split <- function(data) {
  # SHORTCUT functions to add potentially useful exogenous variable
}
library(dygraphs)
eval_pred <- function(x, rv_dt = rv_data) {
  validation_actual <- rv_dt %>% 
    select(date, value) %>% 
    dplyr::slice(validation_count) %>% 
    bind_cols(x) %>% na.omit()
  names(validation_actual) <- c("date", "actual", "pred")
  # plot(validation_actual$actual, validation_actual$pred)
  valid_xts <- xts(validation_actual[, 2:3], order.by = validation_actual$date)
  # pp <- plot(valid_xts)
  # pp <- dygraph(valid_xts) %>%
  #     dySeries("actual", drawPoints = F, color = "#58508d") %>%
  #     dySeries("pred", stepPlot = F, color = "#ffa600")
  rmse <- RMSE(validation_actual)
  # qlike <- qlike(validation_actual)
  # mda <- mda(validation_actual)
  mae <- MAE(validation_actual)
  qlike <- QLIKE(validation_actual)
  mape <- MAPE(validation_actual)
  pp <- dygraph(valid_xts) %>%
    dySeries("actual", drawPoints = F, color = "blue") %>%
    dySeries("pred", stepPlot = F, color = "red")
  return(list(pp = pp, loss = tibble(rmse = rmse, mae = mae, qlike = qlike, mape = mape)))
}

# transform the date from low frequency (monthly) to high frequency (daily)
# and pad the gaps with values from the corresponding month
ym_to_daily <- function(x, to_xts = F) {
  x$date <- as_date(as.yearmon(paste(x$year, x$month, sep = "-")))
  x <- x %>% select(-c(year, month)) %>% 
    pad_by_time(date, .by = "day", .fill_na_direction = "down")
  if(to_xts) {
    x <- xts(x = x %>% select(-date),
             order.by = x$date)
  }
  return(x)
}

