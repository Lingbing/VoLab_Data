# functions to add additional predictors to realized volatility data frame
add_tsvar <- function(data) {
  # add time series feature variables
  # dom: date of month, factor type
  # wday: weekday, factor
  # qtr: quarter of the year, factor
  # month: month of the year, factor
  # data should be a tibble with two columns
  # first column is date variable
  # the second column should be a "value" variable with the rv series
  data_tsvar <- data |> tibble(# day of month
    dom = as.factor(day(date(rv))),
    # weekday
    wday = as.factor(wday(date(rv)) - 1),
    # yday = as.factor(yday(date(lrv))),
    # quarter of year
    qtr = as.factor(quarter(date(rv))),
    # month of year
    month = as.factor(month(date(rv))))
  return(data_tsvar)
}
add_lags <- function(data, k = 22) {
  # add lags to the rv value series
  # default is k = 22
  col_names <- paste0("lag_", 1:k)
  data_lag <- data %>% 
    tq_mutate(
      select     = value,
      mutate_fun = lag.xts,
      k          = 1:k,
      col_rename = col_names
    )
  return(data_lag)
}
add_volcomp <- function(rv_data, rtn = rtn, k_comp = 1) {
  # add volatility component measures: 基于方差因素
  # semivariances and jump component
  # rv_data is a dataframe or a tibble containing at least two columns
  # first column is date, second is value (rv values)
  # rtn is high frequency return seris
  # k_comp is the lag value set for the volatility components
  ep <- endpoints(rtn, on = "days")
  RV <- period.apply(rtn$rtn, INDEX = ep,
                     FUN = function(x) sum(x^2))
  # plot(RV, main = "Realized Volatility Plot")
  # # if log RV is used, then
  # # ln_rv <- log(rv_dat)
  # # slice data by time period
  time_period <- '2018-03-27/2022-12-31'
  rv <- RV[time_period]
  names(rv) <- "rv"
  index(rv) <- as.Date(index(rv))
  rs_plus <- period.apply(rtn$rtn, INDEX = ep, 
                          FUN = function(i) sum((i[sign(i) > 0])^2))[time_period]
  index(rs_plus) <- as.Date(index(rs_plus))
  names(rs_plus) <- "rs_plus"
  # plot(rs_plus)
  rs_minus <- period.apply(rtn$rtn, INDEX = ep, 
                           FUN = function(i) sum((i[sign(i) < 0])^2))[time_period]
  index(rs_minus) <- as.Date(index(rs_minus))
  names(rs_minus) <- "rs_minus"
  # realized quarticity (RQ, Barndorff-Nielsen & Shephard, 2002)
  rq <- period.apply(rtn$rtn, INDEX = ep, 
                     FUN = function(i) sum(i^4)*length(i)/3)[time_period]
  # plot(rq)
  # bi-power variation
  mu <- sqrt(2/pi)
  bv_fun <- function(rt) {
    rt <- coredata(rt)
    a <- abs(rt)
    b <- abs(dplyr::lag(rt, 2))
    M <- length(a)
    return(sum(a*b, na.rm = T) * M/(M - 2))
  }
  
  bv <- mu^(-2) * period.apply(rtn$rtn, INDEX = ep, 
                               FUN = bv_fun)[time_period]
  names(bv) <- "BV"
  index(bv) <- as.Date(index(bv))
  # plot(bv, main = "Bi-power variation plot")
  # tripower quarticity
  mu_2 <- 2^(2/3) * gamma(7/6)* gamma(1/2)
  tq_fun <- function(rt) {
    rt <- coredata(rt)
    a <- abs(rt)^(4/3)
    b_1 <- abs(dplyr::lag(rt, 2))^(4/3)
    b_2 <- abs(dplyr::lag(rt, 4))^(4/3)
    M <- length(a)
    return(sum(a*b_1*b_2, na.rm = T) * M^2/(M - 4))
  }
  tq <- mu_2^(-3) * period.apply(rtn$rtn, INDEX = ep, 
                                 FUN = tq_fun)[time_period]
  names(tq) <- "TQ"
  index(tq) <- as.Date(index(tq))
  # plot(tq, main = "Tri-power variation plot")
  # calculate Z_t as om Andersem et al. (2007) and Huang and Tauchen (2005)
  M <- 48 # daily number of 5-min observations
  Z_t <- sqrt(M) * (rv - bv) * rv^(-1) / ((mu^(-4) + 2*mu^(-2) - 5) * pmax(1, tq*bv^(-2)))
  # Compute (significant) jump component
  alpha <- 0.001 # as in Andersen et al. (2007)
  J_t <- (rv - bv)*(Z_t > qnorm(1 - alpha))
  names(J_t) <- "jump"
  # plot(J_t, main = "Jump component")
  # Continous component of quadratic variation
  C_t <- rv - J_t
  vol_comp <- merge(rs_plus, rs_minus, J_t)
  rv_comp <- cbind(rv_data, rs_minus = unname(coredata(rs_minus)), 
                   rs_plus = unname(coredata(rs_plus)), 
                   J_t = unname(coredata(J_t))) %>%
    tq_mutate(
      select     = rs_minus,
      mutate_fun = lag.xts,
      k          = 1:k_comp,
      col_rename = paste0("RSV+_lag_", 1:k_comp)) %>%
    tq_mutate(
      select     = rs_plus,
      mutate_fun = lag.xts,
      k          = 1:k_comp,
      col_rename = paste0("RSV-_lag_", 1:k_comp)) %>% 
    tq_mutate(
      select     = J_t,
      mutate_fun = lag.xts,
      k          = 1:k_comp,
      col_rename = paste0("Jt_lag_", 1:k_comp)) %>%
    select(-c(rs_minus, rs_plus, J_t))
}

# ab <- rv_data |> add_volcomp(rtn = rtn, k_comp = 5)
