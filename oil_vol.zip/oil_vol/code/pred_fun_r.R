# 0. Roll HAR-RV(1, 5, 22) benchmark model
roll_harrv_pred <- function(x) {
  training <- analysis(x)
  harrv_mat <- na.omit(training) %>% 
    mutate(rv_d = lag_1,
           rv_w = (lag_1+lag_2+lag_3+lag_4+lag_5)/5,
           rv_m = (lag_1+lag_2+lag_3+lag_4+lag_5+lag_6+lag_7+
                     lag_8+lag_9+lag_10+lag_11+lag_12+lag_13+lag_14+
                     lag_15+lag_16+lag_17+lag_18+lag_19+lag_20+
                     lag_21+lag_22)/22) %>% 
    select(value, rv_d, rv_w, rv_m)
  harrv_model <- lm(value ~ rv_d + rv_w + rv_m, data = harrv_mat) # 设定模型
  new <- assessment(x) %>% 
    mutate(rv_d = lag_1,
           rv_w = (lag_1+lag_2+lag_3+lag_4+lag_5)/5,
           rv_m = (lag_1+lag_2+lag_3+lag_4+lag_5+lag_6+lag_7+
                     lag_8+lag_9+lag_10+lag_11+lag_12+lag_13+lag_14+
                     lag_15+lag_16+lag_17+lag_18+lag_19+lag_20+
                     lag_21+lag_22)/22) %>% 
    select(rv_d, rv_w, rv_m)
  pred <- predict(harrv_model, newdata = new)
  return(pred)
}
#-------------------------------------------------------------------------------

# 1. Pure Linear model
roll_lm_pred <- function(x) {
  training = analysis(x) %>% na.omit()
  new <- assessment(x)
  model <- lm(value~., data = select(training, -date))
  pred <- predict(model, newdata = new %>% select(-c(date, value)))
  return(pred)
}
#-------------------------------------------------------------------------------

#  2. LASSO
tidy_lasso <- function(x) {
  set.seed(12345)
  dt <- analysis(x) |> 
    select(-date) |> 
    drop_na()
  dt_split <- initial_split(dt)
  dt_train <- training(dt_split)
  dt_test <- testing(dt_split)
  
  folds <- vfold_cv(dt_train, v = 5)
  
  rec <- recipe(value ~ ., data = dt_train) |> 
    step_center(all_predictors(), -all_nominal()) |>  
    step_dummy(all_nominal())
  
  mod <- linear_reg(mode = "regression",
                    penalty = tune(),
                    mixture = 1) |> set_engine("glmnet")
  
  wf <- workflow() |> add_model(mod) |> add_recipe(rec)
  
   #grid <- grid_regular(penalty(), levels = 50)
   grid <- tibble(penalty = 10^seq(-2, -0.5, length.out = 10))
  
  res <- wf |>
    tune_grid(resamples = folds,
              grid = grid,
              control = control_grid(verbose = FALSE, save_pred = TRUE),
              metrics = metric_set(rmse))
  # 
  # # autoplot(res)
  # 
  best_mod <- res |> select_best("rmse")
  final_fitted <- finalize_workflow(wf, best_mod) |> 
    fit(data = dt_train)
  
  # extract variable importance
  
  # vip <- final_fitted |> 
  #   extract_fit_parsnip() |> 
  #   vi(lambda = best_mod$penalty)
  new_dt <- assessment(x) |> select(-c(date, value))
  pred <- unname(unlist(predict(final_fitted, new_dt)))
  return(list(pred = pred))
}
#-------------------------------------------------------------------------------

# 3. RIDGE
tidy_ridge <- function(x) {
  set.seed(132)
  dt <- analysis(x) |> 
    select(-date) |> 
    drop_na()
  dt_split <- initial_split(dt)
  dt_train <- training(dt_split)
  dt_test <- testing(dt_split)
  folds <- vfold_cv(dt_train, v = 5)
  rec <- recipe(value ~ ., data = dt_train) |> 
    step_center(all_predictors(), -all_nominal()) |>  
    step_dummy(all_nominal())
  ridge_mod <- linear_reg(mode = "regression", #1
                          penalty = tune(),
                          mixture = 0) |> set_engine("glmnet")
  wf <- workflow() |> 
    add_model(ridge_mod) |> 
    add_recipe(rec)
  # grid <- grid_regular(penalty(), levels = 50)
  grid <- tibble(penalty = seq(0.05, 0.5, length = 10))
  res <- wf |> 
    tune_grid(resamples = folds,
              grid = grid,
              control = control_grid(verbose = FALSE, save_pred = TRUE),
              metrics = metric_set(rmse))
  
  # autoplot(res)
  best_mod <- res |> select_best("rmse")
  final_fitted <- finalize_workflow(wf, best_mod) |> 
    fit(data = dt_train)
  new_dt <- assessment(x) |> select(-c(date, value))
  pred <- unname(unlist(predict(final_fitted, new_dt)))
  return(list(pred = pred))
}
#-------------------------------------------------------------------------------

# 4.Elastic net
tidy_ela <- function(x) {
  set.seed(135)
  dt <- analysis(x) |> 
    select(-date) |> 
    drop_na()
  dt_split <- initial_split(dt)
  dt_train <- training(dt_split)
  dt_test <- testing(dt_split)
  folds <- vfold_cv(dt_train, v = 5)
  rec <- recipe(value ~ ., data = dt_train) |> 
    step_center(all_predictors(), -all_nominal()) |>  
    step_dummy(all_nominal())
  
  mod <- linear_reg(mode = "regression",
                    penalty = tune(),
                    mixture = tune()) |> 
    set_engine("glmnet")
  
  wf <- workflow() |> 
    add_model(mod) |> 
    add_recipe(rec)

  grid <- grid_max_entropy(penalty(),
                           mixture(),
                           size = 10)

  res <- wf |>
    tune_grid(resamples = folds,
              grid = grid,
              control = control_grid(verbose = FALSE, save_pred = TRUE),
              metrics = metric_set(rmse))
   best_mod <- res |> select_best("rmse")
  final_fitted <- finalize_workflow(wf, best_mod) |> 
    fit(data = dt_train)
  new_dt <- assessment(x) |> select(-c(date, value))
  pred <- unname(unlist(predict(final_fitted, new_dt)))
  return(list(pred = pred))
}

#-------------------------------------------------------------------------------

# 5. K-nearest neighbor

tidy_knn <- function(x) {
  set.seed(15)
  dt <- analysis(x) |> 
    select(-date) |> 
    drop_na()
  dt_split <- initial_split(dt)
  dt_train <- training(dt_split)
  dt_test <- testing(dt_split)
  folds <- vfold_cv(dt_train, v = 5)
  rec <- recipe(value ~ ., data = dt_train) |> 
    step_center(all_predictors(), -all_nominal()) |>  
    step_dummy(all_nominal())
  
  mod <-
    nearest_neighbor(neighbors = 5, 
                     weight_func = tune(), 
                     dist_power = tune()) %>%
    set_engine('kknn') %>%
    set_mode('regression')
  
  wf <- workflow() |> 
    add_model(mod) |> 
    add_recipe(rec)
  
  grid <- grid_max_entropy(
                           weight_func(),
                           dist_power(),
                           size = 30)
  
  res <- wf |> 
    tune_grid(resamples = folds,
              grid = grid,
              control = control_grid(verbose = FALSE, save_pred = TRUE),
              metrics = metric_set(rmse))
  # toc()
  # stopCluster(cl)
  autoplot(res) |> ggplotly()
  best_mod <- res |> select_best("rmse")
  final_fitted <- finalize_workflow(wf, best_mod) |> 
    fit(data = dt_train)
  # vip <- final_fitted |> 
  #   extract_fit_parsnip() |> 
  #   vi()
  new_dt <- assessment(x) |> select(-c(date, value))
  pred <- unname(unlist(predict(final_fitted, new_dt)))
  return(list(pred = pred))
}

#-------------------------------------------------------------------------------
# 6. Support vector regression

tidy_svr <- function(x) {
  set.seed(16)
  dt <- analysis(x) |> 
    select(-date) |> 
    drop_na()
  dt_split <- initial_split(dt)
  dt_train <- training(dt_split)
  dt_test <- testing(dt_split)
  folds <- vfold_cv(dt_train, v = 5)
  rec <- recipe(value ~ ., data = dt_train) |> 
    step_center(all_predictors(), -all_nominal()) |>  
    step_dummy(all_nominal())
  
  mod <-svm_rbf(cost = tune(), 
                rbf_sigma = tune(), 
                margin = 0.2) %>%
        set_engine('kernlab') %>%
        set_mode('regression')
  
  wf <- workflow() |> 
    add_model(mod) |> 
    add_recipe(rec)
  
  grid <- grid_max_entropy(cost(), 
                           rbf_sigma(),
                           size = 30)
  
  res <- wf |> 
    tune_grid(resamples = folds,
              grid = grid,
              control = control_grid(verbose = FALSE, save_pred = TRUE),
              metrics = metric_set(rmse))
  # toc()
  # stopCluster(cl)
  autoplot(res) |> ggplotly()
  best_mod <- res |> select_best("rmse")
  final_fitted <- finalize_workflow(wf, best_mod) |> 
    fit(data = dt_train)
  # vip <- final_fitted |> 
  #   extract_fit_parsnip() |> 
  #   vi()
  new_dt <- assessment(x) |> select(-c(date, value))
  pred <- unname(unlist(predict(final_fitted, new_dt)))
  return(list(pred = pred))
}
#-------------------------------------------------------------------------------
# 7. mlp

tidy_mlp <- function(x) {
  
  set.seed(17)
  dt <- analysis(x) |> 
    select(-date) |> 
    drop_na()
  dt_split <- initial_split(dt)
  dt_train <- training(dt_split)
  dt_test <- testing(dt_split)
  folds <- vfold_cv(dt_train, v = 5)
  rec <- recipe(value ~ ., data = dt_train) |> 
    step_center(all_predictors(), -all_nominal()) |>  
    step_dummy(all_nominal())
  
  mlp_mod <-
  mlp(hidden_units = tune(), penalty = tune(), epochs = tune()) %>%
  set_engine('nnet') %>%
  set_mode('regression')

  grid <- grid_max_entropy(hidden_units(), 
                           penalty(),
                           epochs(),
                           size = 30)
  
  wf <- workflow() |> 
    add_model(mlp_mod) |> 
    add_recipe(rec)
  
  # grid <- grid_regular(penalty(), levels = 50)
  #grid <- tibble(penalty = seq(0.1, 0.6, length = 20))
  doParallel::registerDoParallel()
  res <- wf |> 
    tune_grid(resamples = folds,
              grid = grid,
              control = control_grid(verbose = FALSE, save_pred = TRUE),
              metrics = metric_set(rmse))
  
  # autoplot(res)
  best_mod <- res |> select_best("rmse")
  final_fitted <- finalize_workflow(wf, best_mod) |> 
    fit(data = dt_train)
  # extract variable importance
  vip <- final_fitted |> 
    extract_fit_parsnip() |> 
    vi(lambda = best_mod$penalty)
  new_dt <- assessment(x) |> select(-c(date, value))
  pred <- unname(unlist(predict(final_fitted, new_dt)))
  return(list(pred = pred, vip = vip))
}

#-------------------------------------------------------------------------------
# 8. Decision trees

tidy_dt <- function(x) {
  set.seed(18)
  dt <- analysis(x) |> 
    select(-date) |> 
    drop_na()
  dt_split <- initial_split(dt)
  dt_train <- training(dt_split)
  dt_test <- testing(dt_split)
  folds <- vfold_cv(dt_train, v = 5)
  rec <- recipe(value ~ ., data = dt_train) |> 
    step_center(all_predictors(), -all_nominal()) |>  
    step_dummy(all_nominal())
  
dt_mod <-
  decision_tree(tree_depth = 3,
                min_n = 3, 
                cost_complexity = 0.03) %>%
  set_engine('rpart') %>%
  set_mode('regression')

# grid <-  grid_max_entropy(tree_depth(),
#                      size = 10)

  
  wf <- workflow() |> 
    add_model(dt_mod) |> 
    add_recipe(rec)
  
  # res <- wf |>
  #   tune_grid(resamples = folds,
  #             grid = grid,
  #             control = control_grid(verbose = FALSE, save_pred = TRUE),
  #             metrics = metric_set(rmse))
  
  # autoplot(res)
 # best_mod <- res |> select_best("rmse")
  final_fitted <- finalize_workflow(wf, dt_mod) |> 
    fit(data = dt_train)
  # extract variable importance
  # vip <- final_fitted |> 
  #   extract_fit_parsnip() |> 
  #   vi(lambda = best_mod$penalty)
  new_dt <- assessment(x) |> select(-c(date, value))
  pred <- unname(unlist(predict(final_fitted, new_dt)))
  return(list(pred = pred))
}

#-------------------------------------------------------------------------------

#-------------------------------------------------------------------------------
# 10. Random forest (RF) model
tidy_rf <- function(x) {
  set.seed(111)
  dt <- analysis(x) %>% select(-date) %>%  drop_na()
  dt_split <- initial_split(dt)
  dt_train <- training(dt_split)
  dt_test <- testing(dt_split)
  folds <- vfold_cv(dt_train, v = 5)
  rec <- recipe(value ~ ., data = dt_train) |> 
    step_center(all_predictors(), -all_nominal()) |>  
    step_dummy(all_nominal())
  
  rf_mod <- rand_forest(mtry = 6, min_n = 7, trees = 500) |> 
    set_engine("ranger", num.threads = 8, 
               importance = "impurity", splitrule = "maxstat") |> 
    set_mode("regression")

  
  wf <- workflow() |> add_model(rf_mod) |> add_recipe(rec)

  
  #best_mod <- res |> select_best("rmse")
  final_fitted <- finalize_workflow(wf, rf_mod) |> 
    fit(data = dt_train)
  # final_fitted |> extract_fit_parsnip() |> vip(15)
  new_dt <- assessment(x) |> select(-c(date, value))
  pred <- predict(final_fitted, new_dt)
  return(pred = pred)
}



#-------------------------------------------------------------------------------
# 11. LightGBM

tidy_lgb <- function(x) {
set.seed(1234)
  dt <- analysis(x) |> 
    select(-date) |> 
    drop_na()
  dt_split <- initial_split(dt)
  dt_train <- training(dt_split)
  dt_test <- testing(dt_split)
  
  folds <- vfold_cv(dt_train, v = 5)
  #数据预处理
  rec <- recipe(value ~ ., data = dt_train) |> 
    step_center(all_predictors(), -all_nominal()) |>  #以0为中心标准化
    step_dummy(all_nominal())
  
  mod <- boost_tree(mtry = tune(), 
                    trees = tune(), 
                    min_n = tune(),
                    tree_depth = tune(),
                    learn_rate = tune(), 
                    sample_size = tune()) |> 
    set_engine("lightgbm", num_threads = 10) |> 
    set_mode("regression")


  grid <- extract_parameter_set_dials(mod) %>%
    finalize(dt_train) %>%
    grid_random(size = 20)
  
  wf <- workflow() |> 
    add_model(mod) |> 
    add_recipe(rec)
  
  res <- wf |> 
    tune_grid(resamples = folds,
              grid = grid,
              control = control_grid(save_pred = TRUE),
              metrics = metric_set(rmse))
  # toc()
  # autoplot(res)
  best_mod <- res |> select_best("rmse")
  final_fitted <- finalize_workflow(wf, best_mod) |> 
    fit(data = dt_train)
  # final_fitted |> extract_fit_parsnip() %>%
  #   vip(geom = "point")
  # vip <- final_fitted |> 
  #   extract_fit_parsnip() |> 
  #   vi()
  new_dt <- assessment(x) |> select(-c(date, value))
  pred <- predict(final_fitted, new_dt)
  return(pred = unlist(pred))
}

#-------------------------------------------------------------------------------
# 12. XGBboost
tidy_xgb <- function(x) {
  set.seed(110)
  dt <- analysis(x) |> 
    select(-date) |> 
    drop_na()
  dt_split <- initial_split(dt)
  dt_train <- training(dt_split)
  dt_test <- testing(dt_split)
  folds <- vfold_cv(dt_train, v = 5)
  rec <- recipe(value ~ ., data = dt_train) |> 
    step_center(all_predictors(), -all_nominal()) |>  
    step_dummy(all_nominal())
  mod <- boost_tree(trees = 1000, 
                    tree_depth = 7, min_n = 6, 
                    loss_reduction = tune(),                     
                    sample_size = 0.75, mtry = tune(),        
                    learn_rate = tune()) |> 
    set_engine("xgboost") |> 
    set_mode("regression")
  
  grid <- grid_latin_hypercube(
    loss_reduction(),
    finalize(mtry(), dt_train),
    learn_rate(),
    size = 10
  )
  
  wf <- workflow() |> 
    add_model(mod) |> 
    add_recipe(rec)
  
  res <- wf |>
    tune_grid(resamples = folds,
              grid = grid,
              control = control_grid(save_pred = TRUE),
              metrics = metric_set(rmse))

  params <- extract_parameter_set_dials(mod) %>%
    finalize(dt_train)
  
  tuned <- tune_bayes(
    wf,
    resamples = folds,
    param_info = params,
    iter = 30,
    metrics = metric_set(rmse),
    initial = 10,
    control = control_bayes(
      verbose = TRUE,
      no_improve = 10,
      seed = 123
    )
  )

  best_mod <- res |> select_best("rmse")
  final_fitted <- finalize_workflow(wf, best_mod) |> 
    fit(data = dt_train)
  # final_fitted |> extract_fit_parsnip() %>%
  #   vip::vip(geom = "point")
  new_dt <- assessment(x) |> select(-c(date, value))
  pred <- predict(final_fitted, new_dt)
  return(pred = unlist(pred))
}

#-------------------------------------------------------------------------------







