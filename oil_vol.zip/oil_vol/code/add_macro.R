library(pacman) 
p_load(readxl, lubridate, xts, tidyverse)

# 0. Daily EPU
daily_k <- 5
monthly_k <- 1
d_epu <- read_csv("data/epu/All_Daily_Policy_Data.csv") %>% 
  mutate(date = ymd(paste(year, month, day, sep = "-"))) %>% 
  rename(depu = daily_policy_index) %>% 
  select(date, depu) %>% 
  tq_mutate(
    select     = depu,
    mutate_fun = lag.xts,
    k          = 1:daily_k,
    col_rename = paste0("depu_lag", 1:daily_k)
  )

# 1. China EPU data (monthly from 1951-1 on)
CN_EPU <- read_excel("data/China_Mainland_Paper_EPU.xlsx", sheet = "EPU 2000 onwards",
                     col_types = c("numeric", "numeric", "numeric",
                                   "skip", "skip", "skip")) %>% 
  mutate(cnepu_lag1 = lag(EPU, k = monthly_k))
cn_epu <- ym_to_daily(CN_EPU)
names(cn_epu)[1] <- "cn_epu"
# plot(cn_epu)

# 2. Global Policy uncertainty data (ppp adjusted)
GPU <- read_excel("data/Global_Policy_Uncertainty_Data.xlsx")[-303, -3] %>% 
  rename(year = Year, month = Month, gpu = GEPU_ppp) %>% 
  mutate(gpu_lag1 = lag(gpu, k = monthly_k))
gepu <- ym_to_daily(GPU)
# plot(gepu)
# cor(GPU$GEPU_current, GPU$GEPU_ppp)
# the correlation is too high, we pick the ppp GPU for use

# 3. The WUICHN index (quarterly)
# World Uncertainty Index for China, obtained from FRED.
WUICHN <- read_excel("data/WUICHN.xlsx", col_types = c("date", "numeric")) %>% 
  mutate(wuichn_lag1 = lag(WUICHN, k = 1)) %>% 
  pad_by_time(DATE, .by = "day", .fill_na_direction = "down") 
wuichn <- rename(WUICHN, date = DATE) %>% 
  mutate(date = ymd(date))
# plot(wuichn)

# 4. China EPU Index Based on the South China Morning Post
S_CPU <- read_excel("scpu.xlsx")
names(S_CPU)[3] <- "scpu"
scpu <- S_CPU %>% 
  mutate(scpu_lag1 = lag(scpu, k=1)) 
scpu <- ym_to_daily(scpu)
# plot(scpu)

# 5. Financial Stress Index (choose monthly, data only up to 2016-12)
# FSI <- read_excel("Financial_Stress.xlsx", sheet = "Monthly Financial Stress") %>% 
#   select(year, month, indicator)
# fsi <- ym_to_daily(FSI)
# plot(fsi)

# 6. overall Equity Market Volatility
EMV <- read_excel("data/EMV_Data.xlsx") %>% 
  select(1:3) %>% rename(year = Year, month = Month, emv = "Overall EMV Tracker") %>% 
  mutate(emv_lag1 = lag(emv, k=1)) 
emv <- ym_to_daily(EMV)
# plot(emv)


# 7. Daily Infectious Disease Equity Market Volatility Tracker
# This is daily index
iemv <- read_csv("All_Infectious_EMV_Data.csv") %>% 
  mutate(date = ymd(paste(year, month, day, sep = "-"))) %>% 
  rename(iemv = daily_infect_emv_index) %>% 
  select(date, iemv) %>% 
  tq_mutate(
    select     = iemv,
    mutate_fun = lag.xts,
    k          = 1:daily_k,
    col_rename = paste0("iemv_lag", 1:daily_k)
  )

# 8. Geopolitical Risk Measure (GPR)
gpr <- na.omit(read_excel("data/data_gpr_export.xls",
                          col_types = c("date", "numeric"))) %>% 
  rename(date = month) %>% mutate(gpr_lag1 = lag(GPR, k=1)) %>% 
  pad_by_time(date, .by = "day", .fill_na_direction = "down") 

# 9. China TPU
CN_TPU <- read_excel("data/China_Mainland_Paper_EPU.xlsx", sheet = "TPU 2000 onwards",
                     col_types = c("numeric", "numeric", "numeric",
                                   "skip", "skip", "skip")) %>% 
  mutate(cntpu_lag1 = lag(TPU, k=1))
cn_tpu <- ym_to_daily(CN_TPU)

# 10. Janpanese EPU
j_epu<- read_excel("data/Japan_Policy_Uncertainty_Data.xlsx", 
                   sheet = "Main Index") %>% 
  rename(year = Year, month = Month, jepu = "News-based Economic Policy Uncertainty Index") %>% 
  mutate(jepu_lag1 = lag(jepu, k = 1)) %>% 
  ym_to_daily(.)

# 11. Chinese VIX index (Daily)
# consider long lags in the future
cvix <- read_excel("data/CVIX.xlsx", col_types = c("date", "numeric"), na = ".") %>%
  rename(date= DATE, cvix = VXFXICLS) %>%
  mutate(cvix = na.locf(cvix)) %>% 
  tq_mutate(
    select     = cvix,
    mutate_fun = lag.xts,
    k          = 1:daily_k,
    col_rename = paste0("cvix_lag", 1:daily_k)
  )

# 12. VIX index
vix <- read_excel("VIX_History.xlsx",
                  col_types = c("text","skip", "skip", "skip", "numeric")) %>% 
  mutate(date = mdy(DATE), vix = CLOSE) %>% 
  tq_mutate(
    select     = vix,
    mutate_fun = lag.xts,
    k          = 1:daily_k,
    col_rename = paste0("vix_lag", 1:daily_k)
  ) %>% select(-c(DATE, CLOSE))

# Macroeconomic data
# 1. CPI data (monthly)
# we lag daily predictor varaible to 21 lags
# read_monthly <- function(file_path) {
#   read_excel(file_path, col_types = c("text", "numeric")) %>% 
#     mutate(date = as.Date(as.yearmon(date)),
#            pmio_lag1 = lag(pmi, k = 1)) %>%
#     select(-pmi) %>% 
#     pad_by_time(date, .by = "day", .fill_na_direction = "down")
# }
cpi <- read_excel("data/macro_data/cpi.xlsx", 
                  col_types = c("text", "numeric")) %>% 
  mutate(date = as.Date(as.yearmon(date)),
         cpi_lag1 = lag(cpi, k = 1)) %>%
  select(-cpi) %>% 
  pad_by_time(date, .by = "day", .fill_na_direction = "down")
# sum(is.na(cpi$cpi_lag1))
# no missings
# 2. PMI official data
pmi_o <- read_excel("data/macro_data/pmi_official.xlsx", 
                    col_types = c("text", "numeric")) %>% 
  mutate(date = as.Date(as.yearmon(date)),
         pmio_lag1 = lag(pmi, k = 1)) %>%
  select(-pmi) %>% 
  pad_by_time(date, .by = "day", .fill_na_direction = "down")
# sum(is.na(pmi_o))
# 3. PMI caixin data
pmi_cx <- read_excel("data/macro_data/pmi_caixin.xlsx", 
                     col_types = c("text", "numeric")) %>% 
  mutate(date = as.Date(as.yearmon(date)),
         pmicx_lag1 = lag(pmi_caixin, k = 1)) %>%
  select(-pmi_caixin) %>% 
  pad_by_time(date, .by = "day", .fill_na_direction = "down")
# sum(is.na(pmi_cx))
# 4. M2 data (monthly)
m2 <- read_excel("data/macro_data/m2.xlsx", 
                 col_types = c("text", "numeric")) %>% 
  mutate(date = as.Date(as.yearmon(date)),
         m2_lag1 = lag(m2, k = 1)) %>%
  select(-m2) %>% 
  pad_by_time(date, .by = "day", .fill_na_direction = "down")
# sum(is.na(m2))
# 5. PPI data (monthly)
ppi <- read_excel("data/macro_data/ppi.xlsx", 
                  col_types = c("text", "numeric")) %>% 
  mutate(date = as.Date(as.yearmon(date)),
         ppi_lag1 = lag(ppi, k = 1)) %>%
  select(-ppi) %>% 
  pad_by_time(date, .by = "day", .fill_na_direction = "down")
# sum(is.na(ppi))
# 6. USD dollar exchange rate data (daily)
# we lag daily predictor to 21 lags
usd <- read_excel("data/macro_data/usd.xlsx", 
                  col_types = c("text", "numeric")) %>% 
  mutate(date = ymd(date)) %>% 
  tq_mutate(
    select     = usd,
    mutate_fun = lag.xts,
    k          = 1:daily_k,
    col_rename = paste0("usd_lag", 1:daily_k)) %>%
  select(-usd)
head(usd)

# 7. EURO exchange rate data (daily)
euro <- read_excel("data/macro_data/euro.xlsx", 
                   col_types = c("text", "numeric")) %>% 
  mutate(date = ymd(date)) %>% 
  tq_mutate(
    select     = euro,
    mutate_fun = lag.xts,
    k          = k,
    col_rename = paste0("euro_lag", k)) %>%
  select(-euro)
# sum(is.na(euro))
# 8. JPY exchange rate data (daily)
jpy <- read_excel("data/macro_data/jpy.xlsx", 
                  col_types = c("text", "numeric")) %>% 
  mutate(date = ymd(date)) %>% 
  tq_mutate(
    select     = jpy,
    mutate_fun = lag.xts,
    k          = 1:daily_k,
    col_rename = paste0("jpy_lag", 1:daily_k)) %>%
  select(-jpy)
# sum(is.na(jpy))

# exo_cars <- c(cn_epu, gpu, WUICHN, scpu, emv, iemv, GPR, TPU, jepu, cvix, vix)
# merge with the index data
rv_exo <- rv_dat2 %>% 
  left_join(d_epu, by = "date") %>% 
  left_join(cn_epu, by = "date")%>%
  left_join(gepu, by = "date") %>%
  left_join(wuichn, by = "date") %>%
  left_join(scpu, by = "date") %>%
  left_join(emv, by = "date") %>%
  left_join(iemv, by = "date") %>%
  left_join(gpr, by = "date") %>%
  left_join(cn_tpu, by = "date") %>%
  left_join(j_epu, by = "date") %>%
  left_join(cvix, by = "date") %>%
  left_join(vix, by = "date") %>%
  left_join(cpi, by = "date") %>%
  left_join(pmi_o, by = "date") %>%
  left_join(pmi_cx, by = "date") %>%
  left_join(m2, by = "date") %>%
  left_join(ppi, by = "date") %>%
  left_join(usd, by = "date") %>%
  left_join(euro, by = "date") %>%
  left_join(jpy, by = "date")%>%
  select(date:value, contains("lag"))
sapply(rv_exo, function(i) sum(is.na(i)))
rv_exo<- na.locf(rv_exo, na.rm = F)
sapply(rv_exo, function(i) sum(is.na(i)))
