system.time(harrv_bench <- pbsapply(splits$splits, roll_harrv_pred))
(bench <- eval_pred(harrv_bench))

# 加载变量的名称
dt2 <- read_excel('test.xlsx')[1,]
dt2 <- as.tibble(lapply(dt2,as.numeric))
lgbi<- as(as.matrix(dt2), "dgCMatrix")

tidy_lgb <- function(x) {
  set.seed(1234)
  dt <- analysis(x) |> 
    select(-date) |> 
    drop_na()
  dt_split <- initial_split(dt)
  dt_train <- training(dt_split)
  dt_test <- testing(dt_split)
  
  folds <- vfold_cv(dt_train, v = 5)
  #数据预处理
  rec <- recipe(value ~ ., data = dt_train) |> 
    step_center(all_predictors(), -all_nominal()) |>  
    step_dummy(all_nominal())
  
  lgb_mod <- boost_tree(mtry = 8, 
                        trees = 1100, 
                        min_n = 8,
                        tree_depth = 10,
                        learn_rate = 0.017) |> 
    set_engine("lightgbm", num_threads = 10) |> 
    set_mode("regression")
  
  wf <- workflow() |> add_model(lgb_mod) |> add_recipe(rec)
  final_fitted <- finalize_workflow(wf, lgb_mod) |> 
    fit(data = dt_train)
  vip <- extract_fit_engine(final_fitted) %>% lightgbm::lgb.interprete(lgbi, 1L)
  new_dt <- assessment(x) |> select(-c(date, value))
  pred <- predict(final_fitted, new_dt)
  return(list(pred = pred, vip=vip))
}

system.time(lgb_try <- pbsapply(splits$splits, tidy_lgb))
lgb_pred <- unlist(lgb_try)
lgb_pred <- unlist(lgb_try[seq(1,length(lgb_try),2)])
(lgb_re <- eval_pred(lgb_pred))
R2(lgb_pred)
cw(lgb_pred)
HAR_bench$date

#------------SHAP values 提取
Model_pred <- rv_data %>% 
  select(date, value) %>% 
  dplyr::slice(validation_count) %>% 
  bind_cols(lgb_pred)  %>% na.omit()
names(Model_pred) <- c("date", "actual", "pred")

view(Model_pred)
lgb_vip<- lgb_try[seq(0,length(lgb_try),2)]
lgb_vip1 <- (purrr::map(lgb_vip, function(i) as.data.frame(i)[c('Feature', 'Contribution')]))
result_0 <- reduce(lgb_vip1,full_join,by='Feature')

colnames(result_0) <- c('Feature', as.character(HAR_bench$date))
view(result_0)
result_vip <- pivot_longer(result_0, cols = -1, names_to = 'date', values_to = 'shap_value') %>% 
              mutate(date = ymd(date))

shap_f <- pivot_wider(result_vip, names_from = Feature, values_from = shap_value) %>% select(contains('_lag1'))
#------------------------

vip_p <- result_vip %>% group_by(Feature) %>% 
  summarise(shap_value = mean(shap_value, na.rm = T)) %>% arrange(-shap_value) 
top <- rbind(vip_p[1:5,], vip_p[94:98,])
library(ggsci)
p11 <- ggplot(top, aes(fct_reorder(Feature,shap_value), shap_value, fill=Feature)) + 
  geom_bar(stat = "identity",width=0.9, fill = 'grey')+
  scale_fill_futurama()+
  coord_flip()+
  theme_bw()+
  xlab('Feature')+
  ylab('mean(SHAP values)')+
  guides(fill=F)+
  theme(axis.ticks.length = unit(-0.1, 'cm'))




vip_p <- result_vip %>% group_by(Feature) %>% 
  summarise(shap_value = mean(abs(shap_value), na.rm = T)) %>% arrange(-shap_value) 

library(ggsci)
p22 <- ggplot(vip_p[1:10,], aes(fct_reorder(Feature,shap_value), shap_value, fill=Feature)) + 
  geom_bar(stat = "identity",width=0.9)+
  coord_flip()+
  scale_fill_futurama()+
  theme_bw()+
  xlab('')+
  ylab('mean(|SHAP values|)')+
  guides(fill=F)+
  theme(axis.ticks.length = unit(-0.1, 'cm'))

library(patchwork)
p11|p22

hartype <- result_vip %>% filter_all(any_vars(str_detect(.,pattern = 'lag_')))
har_type <- hartype %>% group_by(date) %>%
  summarise(shap_value = mean(abs(shap_value), na.rm=T)) %>% 
  mutate(type = (rep('HAR_type',232))) 


timetype <- result_vip %>% filter_all(any_vars(str_detect(.,pattern = '_X')))
time_type <- timetype %>% group_by(date) %>%
  summarise(shap_value = mean(abs(shap_value), na.rm=T)) %>% 
  mutate(type = (rep('Time_type',232))) 

vartype <- result_vip %>% filter_all(any_vars(str_detect(.,pattern = 'lag1')))
var_type <- vartype %>% group_by(date) %>%
  summarise(shap_value = mean(abs(shap_value), na.rm=T)) %>%
  mutate(type = (rep('Var_type',232))) 

data_p <- rbind(har_type, time_type, var_type) %>% mutate(date = ymd(date))

colnames(data_p)= c('date', 'shap_vlaue', 'Var_type')
p1 = ggplot(data_p, aes(date, shap_vlaue, group=Var_type, color = Var_type)) +
  geom_line() +
  scale_color_futurama()+
  scale_x_date(date_breaks = "15 day", expand=c(0,0))+
  theme_linedraw()+
  theme(axis.text.x = element_text(angle = 45, size=8, hjust = 1))+
  theme(panel.grid = element_blank(), panel.background = element_rect(color = "black",fill = "transparent"))+
  xlab('')+
  ylab('mean(|SHAP value|)')

p2 = ggplot(HAR_bench, aes(date, ben_actual)) +
  geom_line(color = 'steelblue')+
  scale_x_date(date_breaks = "15 day", expand=c(0,0))+
  theme_linedraw()+
  # theme(axis.text.x = element_text(angle = 40, size=5, hjust = 1))+
  theme(axis.text.x = element_text(angle = 45, size=8, hjust = 1))+
  theme(panel.grid = element_blank(), panel.background = element_rect(color = "black",fill = "transparent"))+
  xlab('')+
  ylab('RV')
p1/p2


# data_p <- rbind(har_type, time_type, var_type) %>% mutate(date = ymd(date))
# colnames(data_p) = c('date', 'shap_values', '  ')
# 
# p1 = ggplot(data_p, aes(date, shap_values, group=`  `, linetype = `  `)) +
#   geom_line() +
#   scale_color_futurama()+
#   scale_x_date(date_breaks = "15 day", expand=c(0,0))+
#   theme_linedraw()+
#   theme(axis.text.x = element_text(angle = 45, size=8, hjust = 1),
#         axis.ticks.length = unit(-0.1, 'cm'))+
#   theme(panel.grid = element_blank(), panel.background = element_rect(color = "black",fill = "transparent"))+
#   xlab('')+
#   ylab('mean(|SHAP value|)')+
#   theme(legend.position = c(0.73,0.93))
# 
# p2 = ggplot(HAR_bench, aes(date, ben_actual)) +
#   geom_line(color = 'black')+
#   scale_x_date(date_breaks = "15 day", expand=c(0,0))+
#   theme_linedraw()+
#   # theme(axis.text.x = element_text(angle = 40, size=5, hjust = 1))+
#   theme(axis.text.x = element_text(angle = 45, size=8, hjust = 1),
#         axis.ticks.length = unit(-0.1, 'cm'))+
#   theme(panel.grid = element_blank(), panel.background = element_rect(color = "black",fill = "transparent"))+
#   xlab('')+
#   ylab('RV')
#   #geom_vline(xintercept = ymd('2022-10-10'), color = "darkgrey")
# 

#library(patchwork)
p1/p2

result_vip

na <- filter(result_vip,  Feature == 'EPU_global_lag1'|	Feature =='EPU_cn_lag1'|Feature =='GECON_lag1'|
               Feature == 'RCPF_lag1'|	Feature =='GPR_lag1'|	Feature =='CPI_lag1'|Feature ==	'GIP_lag1'	|
               Feature =='M1_lag1'|Feature ==	'GDP_lag1'|Feature ==	'OVX_lag1'|Feature ==	'PEMV_lag1'	|
               Feature =='IDEMV_lag1'	|Feature =='OEMV_lag1') %>% filter(date > '2022-11-22'&date < '2022-12-22')

na1 <- na %>% group_by(Feature) %>% summarise(shap_value = mean(abs(shap_value))) %>% 
                                    arrange(-shap_value)

naz <- na %>% filter(Feature == 'OVX_lag1'|	Feature =='EPU_cn_lag1' | Feature=='RCPF_lag1'|
                       Feature=='GIP_lag1'|Feature == 'IDEMV_lag1')

c <- ggplot(na1[1:5,], aes(fct_reorder(Feature,shap_value), shap_value, fill=Feature)) + 
  geom_bar(stat = "identity",width=0.9)+
  coord_flip()+
  scale_fill_futurama()+
  theme_bw()+
  xlab('')+
  ylab('mean(|SHAP values|)')+
  guides(fill=F)+
  theme(axis.ticks.length = unit(-0.1, 'cm'))



library(ggsci)
# a=ggplot(naz, aes(date, shap_value, group=Feature, linetype = Feature)) +
#   geom_line() +
#  # geom_rect(xmin =ymd('2022-12-07'),xmax =ymd('2022-12-22'), ymin=-Inf,ymax=Inf,fill="darkgray",alpha=0.006)+
#   scale_color_npg()+
#   scale_x_date(date_breaks = "2 day", expand=c(0,0))+
#   theme_linedraw()+
#  # scale_y_continuous(breaks = seq(-0.6, 0.2, by = 0.1), limits=c(-0.6,0.2)) +
#   theme(axis.text.x = element_text(angle = 45, size=8, hjust = 1),
#         axis.ticks.length = unit(-0.1, 'cm'))+
#   theme(panel.grid = element_blank(), panel.background = element_rect(color = "black",fill = "transparent"))+
#   xlab('')+
#   ylab('SHAP values')+
#   geom_vline(xintercept = ymd('2022-12-07'), color = "darkgrey")+
#   geom_hline(yintercept = 0, color = "darkgrey")+
#   theme(legend.position = c(0.83,0.43))
# a/b
# 
# rvv <- HAR_bench %>% filter(date > '2022-11-22'&date < '2022-12-22')
# b=ggplot(rvv, aes(date, ben_actual)) +
#   geom_line(color = 'black')+
#   scale_x_date(date_breaks = "2 day", expand=c(0,0))+
#   theme_linedraw()+
#   # theme(axis.text.x = element_text(angle = 40, size=5, hjust = 1))+
#   theme(axis.text.x = element_text(angle = 45, size=8, hjust = 1),
#         axis.ticks.length = unit(-0.1, 'cm'))+
#   theme(panel.grid = element_blank(), panel.background = element_rect(color = "black",fill = "transparent"))+
#   xlab('')+
#   ylab('RV')+
#   geom_vline(xintercept = ymd('2022-12-07'), color = "darkgrey")
# 
# library(patchwork)
# a/b

a=ggplot(naz, aes(date, shap_value, group=Feature, color = Feature)) +
  geom_line() +
  # geom_rect(xmin =ymd('2022-12-07'),xmax =ymd('2022-12-22'), ymin=-Inf,ymax=Inf,fill="darkgray",alpha=0.006)+
  scale_color_npg()+
  scale_x_date(date_breaks = "2 day", expand=c(0,0))+
  theme_linedraw()+
  # scale_y_continuous(breaks = seq(-0.6, 0.2, by = 0.1), limits=c(-0.6,0.2)) +
  theme(axis.text.x = element_text(angle = 45, size=8, hjust = 1),
        axis.ticks.length = unit(-0.1, 'cm'))+
  theme(panel.grid = element_blank(), panel.background = element_rect(color = "black",fill = "transparent"))+
  xlab('')+
  ylab('mean(SHAP value)')+
  geom_vline(xintercept = ymd('2022-12-07'), color = "darkgrey")

rvv <- HAR_bench %>% filter(date > '2022-11-22'&date < '2022-12-22')
b=ggplot(rvv, aes(date, ben_actual)) +
  geom_line(color = 'skyblue')+
  scale_x_date(date_breaks = "2 day", expand=c(0,0))+
  theme_linedraw()+
  # theme(axis.text.x = element_text(angle = 40, size=5, hjust = 1))+
  theme(axis.text.x = element_text(angle = 45, size=8, hjust = 1),
        axis.ticks.length = unit(-0.1, 'cm'))+
  theme(panel.grid = element_blank(), panel.background = element_rect(color = "black",fill = "transparent"))+
  xlab('')+
  ylab('RV')+
  geom_vline(xintercept = ymd('2022-12-07'), color = "darkgrey")

library(patchwork)
a/b


x <- result_vip %>% filter(date == '2022-03-10') %>% filter(  Feature == 'EPU_global_lag1'|	Feature =='EPU_cn_lag1'|Feature =='GECON_lag1'|
                                                                Feature == 'RCPF_lag1'|	Feature =='GPR_lag1'|	Feature =='CPI_lag1'|Feature ==	'GIP_lag1'	|
                                                                Feature =='M1_lag1'|Feature ==	'GDP_lag1'|Feature ==	'OVX_lag1'|Feature ==	'PEMV_lag1'	|
                                                                Feature =='IDEMV_lag1'	|Feature =='OEMV_lag1') %>% arrange(-abs(shap_value))

xx = x[1:5,]
x2 <- result_vip %>% filter(date == '2022-06-06') %>% filter(  Feature == 'EPU_global_lag1'|	Feature =='EPU_cn_lag1'|Feature =='GECON_lag1'|
                                                                 Feature == 'RCPF_lag1'|	Feature =='GPR_lag1'|	Feature =='CPI_lag1'|Feature ==	'GIP_lag1'	|
                                                                 Feature =='M1_lag1'|Feature ==	'GDP_lag1'|Feature ==	'OVX_lag1'|Feature ==	'PEMV_lag1'	|
                                                                 Feature =='IDEMV_lag1'	|Feature =='OEMV_lag1')%>% arrange(-abs(shap_value))
xx2 = x2[1:5,]
x3 <- result_vip %>% filter(date == '2022-10-10') %>% filter(  Feature == 'EPU_global_lag1'|	Feature =='EPU_cn_lag1'|Feature =='GECON_lag1'|
                                                                 Feature == 'RCPF_lag1'|	Feature =='GPR_lag1'|	Feature =='CPI_lag1'|Feature ==	'GIP_lag1'	|
                                                                 Feature =='M1_lag1'|Feature ==	'GDP_lag1'|Feature ==	'OVX_lag1'|Feature ==	'PEMV_lag1'	|
                                                                 Feature =='IDEMV_lag1'	|Feature =='OEMV_lag1')%>% arrange(-abs(shap_value))


xx3 = x3[1:5,]

x4 <- result_vip %>% filter(date == '2022-3-30') %>% filter(  Feature == 'EPU_global_lag1'|	Feature =='EPU_cn_lag1'|Feature =='GECON_lag1'|
                                                                Feature == 'RCPF_lag1'|	Feature =='GPR_lag1'|	Feature =='CPI_lag1'|Feature ==	'GIP_lag1'	|
                                                                Feature =='M1_lag1'|Feature ==	'GDP_lag1'|Feature ==	'OVX_lag1'|Feature ==	'PEMV_lag1'	|
                                                                Feature =='IDEMV_lag1'	|Feature =='OEMV_lag1')%>% arrange(-abs(shap_value))


xx4 = x4[1:5,]

r <- rbind(xx,xx2,xx3,xx4)
r$date=as.factor(r$date)

ggplot(r,aes(date,shap_value, fill = Feature))+
  geom_bar(stat="identity",position="stack")+
  theme(panel.grid = element_blank(), panel.background = element_rect(color = "black",fill = "transparent"))+
  theme(axis.ticks.length = unit(-0.1, 'cm'))+
  scale_fill_npg()+
  coord_flip()

# 
# +
#   theme(legend.position = c(0.875,0.67))



contains('_lag')

