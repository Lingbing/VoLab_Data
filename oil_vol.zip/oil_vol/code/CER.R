# 思路：根据endpoints找到每天的收盘价
# 根据收盘价计算log return （百分比）
# （固定窗口）滚动向前预测
# 预测使用auto.arima函数，因此每一步都是相对最优的，而不是固定AR(1)

index <- readxl::read_xlsx("da_2.xlsx") 
index$date = ymd(index$date)
index.xts <- xts(index$close, order.by = index$date)
ep <- endpoints(rtn, on = "days")
# get the closing price for each day
close_price <- index.xts[ep]
time_period <- '2018-03-27/2022-12-31'
close_price <- close_price[time_period]
log_rtn <- makeReturns(close_price)*100
length(log_rtn)

plot(merge(log_rtn, RV))

# rolling prediction to get r_hat
holdout_len <- length(log_rtn) - initial_count
r_p <- rep(NA, holdout_len)
for (i in 1:holdout_len) {
  # different from using AR(1) foe all forecasts
  # we use automatic optimal ARIMA models to predict r_{t+1}
  fit <- auto.arima(log_rtn[i:(initial_count - 1 + i)])
  # browser()
  r_p[i] <- forecast(fit, h = 1)$mean
}
# below are some checking on the predicted return and real return
# in out-of-sample period. 
r_real <- tail(log_rtn, holdout_len)
r_p_xts <- xts(r_p, order.by = index(r_real))

plot(merge(r_real, r_p_xts))

#三个月国债收益率
r_f <- readxl::read_xlsx("/Users/r/Desktop/rf.xlsx") 
r_f.xts <- xts(r_f$rate, order.by = r_f$date)
r_f <- r_f.xts          
names(r_f) <- 'rate'

# 处理一下预测值
# 提取预测值
test <- rv_data %>% 
  select(date, value) %>% 
  dplyr::slice(validation_count) %>% 
  bind_cols(xgb_pred)  %>% na.omit() %>% select(1,3)

sigma_hat <- xts(test$...3,  order.by = test$date)

r_p1 = r_p - r_f
r_p2 = r_real-r_f
eta = 1
theta =6
omega <- ((1/eta) * (theta * r_p1) + (theta - 1) * r_f)/(theta^2 * sigma_hat)
omega[omega$rate <= -1.5] = -1.5
omega[omega$rate >= 1.5] = 1.5
R_p <- omega * theta * (r_p2 + r_f) + (1 - omega) * r_f
(R_p_bar <- mean(R_p))
sigma_R_p <- sd(R_p)
(CER <- R_p_bar - 0.5 * eta * sigma_R_p^2)
(SR <- mean(R_p - r_f)/sd(R_p - r_f))


training.xts <- xts(training$close, order.by = training$date)
















