library(MCS)
# 要先运行所有模型 提取预测值
HAR_bench <- rv_data %>% 
  select(date, value) %>% 
  dplyr::slice(validation_count) %>% 
  bind_cols(harrv_bench)  %>% na.omit()
names(HAR_bench) <- c("date", "ben_actual", "ben_pred")

x <- LossVol(HAR_bench$ben_actual, HAR_bench$ben_pred, which = "AE1") %>%
  as.data.frame() %>% 
  mutate(date = HAR_bench$date) %>% rename(har = V1)

knn <- rv_data %>% 
  select(date, value) %>% 
  dplyr::slice(validation_count) %>% 
  bind_cols(knn_pred)  %>% na.omit()
names(knn) <- c("date", "actual", "pred")

x1 <- LossVol(knn$actual, knn$pred, which = "AE1") %>%
  as.data.frame() %>% 
  mutate(date = knn$date) %>% rename(knn = V1)


svr <- rv_data %>% 
  select(date, value) %>% 
  dplyr::slice(validation_count) %>% 
  bind_cols(svr_pred)  %>% na.omit()
names(svr) <- c("date", "actual", "pred")

x2 <- LossVol(svr$actual, svr$pred, which = "AE1") %>%
  as.data.frame() %>% 
  mutate(date = svr$date) %>% rename(svr = V1)


mlp <- rv_data %>% 
  select(date, value) %>% 
  dplyr::slice(validation_count) %>% 
  bind_cols(mlp_pred)  %>% na.omit()
names(mlp) <- c("date", "actual", "pred")

x3 <- LossVol(mlp$actual, mlp$pred, which = "AE1") %>%
  as.data.frame() %>% 
  mutate(date = mlp$date) %>% rename(mlp = V1)


dt <- rv_data %>% 
  select(date, value) %>% 
  dplyr::slice(validation_count) %>% 
  bind_cols(dt_pred)  %>% na.omit()
names(dt) <- c("date", "actual", "pred")

x4 <- LossVol(dt$actual, dt$pred, which = "AE1") %>%
  as.data.frame() %>% 
  mutate(date = dt$date) %>% rename(dt = V1)


lasso <- rv_data %>% 
  select(date, value) %>% 
  dplyr::slice(validation_count) %>% 
  bind_cols(lasso_pred)  %>% na.omit()
names(lasso) <- c("date", "actual", "pred")

l1 <- LossVol(lasso$actual, lasso$pred, which = "AE1") %>%
  as.data.frame() %>% 
  mutate(date = lasso$date) %>% rename(lasso = V1)

ridge <- rv_data %>% 
  select(date, value) %>% 
  dplyr::slice(validation_count) %>% 
  bind_cols(ridge_pred)  %>% na.omit()
names(ridge) <- c("date", "actual", "pred")
l2 <- LossVol(ridge$actual, ridge$pred, which = "AE1") %>%
  as.data.frame() %>% 
  mutate(date = ridge$date) %>% rename(ridge = V1)

ela <- rv_data %>% 
  select(date, value) %>% 
  dplyr::slice(validation_count) %>% 
  bind_cols(ela_pred)  %>% na.omit()
names(ela) <- c("date", "actual", "pred")
l3 <- LossVol(ela$actual, ela$pred, which = "AE1") %>%
  as.data.frame() %>% 
  mutate(date = ela$date) %>% rename(ela = V1)

#-------------------------------------------------------------------------

rf <- rv_data %>% 
  select(date, value) %>% 
  dplyr::slice(validation_count) %>% 
  bind_cols(rf_pred)  %>% na.omit()
names(rf) <- c("date", "actual", "pred")
r1 <- LossVol(rf$actual, rf$pred, which = "AE1") %>%
  as.data.frame() %>% 
  mutate(date = rf$date) %>% rename(rf = V1)


xgb <- rv_data %>% 
  select(date, value) %>% 
  dplyr::slice(validation_count) %>% 
  bind_cols(xgb_pred)  %>% na.omit()
names(xgb) <- c("date", "actual", "pred")
r2 <- LossVol(xgb$actual, xgb$pred, which = "AE1") %>%
  as.data.frame() %>% 
  mutate(date = xgb$date) %>% rename(xgb = V1)

cat <- rv_data %>% 
  select(date, value) %>% 
  dplyr::slice(validation_count) %>% 
  bind_cols(cat_pred)  %>% na.omit()
names(cat) <- c("date", "actual", "pred")
r3 <- LossVol(cat$actual, cat$pred, which = "AE1") %>%
  as.data.frame() %>% 
  mutate(date = cat$date) %>% rename(cat = V1)


lgb <- rv_data %>% 
  select(date, value) %>% 
  dplyr::slice(validation_count) %>% 
  bind_cols(lgb_pred)  %>% na.omit()
names(lgb) <- c("date", "actual", "pred")
r4 <- LossVol(lgb$actual, lgb$pred, which = "AE1") %>%
  as.data.frame() %>% 
  mutate(date = lgb$date) %>% rename(lgb = V1)

?LossVol

mcs <- left_join(x, x3,by='date')%>%
  left_join(x1, by = 'date') %>%
  left_join(x2, by = 'date') %>%
  left_join(x4, by = 'date') %>%
  left_join(l1, by = 'date') %>%
   left_join(l2, by = 'date') %>%
   left_join(l3, by = 'date') %>%
   left_join(r1, by = 'date') %>%
   left_join(r2, by = 'date') %>%
   left_join(r3, by = 'date') %>%
   left_join(r4, by = 'date') %>%
  drop_na() %>% 
  select(-date) %>% as.matrix()


MCSprocedure(mcs, alpha = 0.2, B = 5000, statistic='Tmax')
sum(is.na(mcs))
view(mcs)

