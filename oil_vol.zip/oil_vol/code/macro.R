source("pred_funs.R")
source("funs-copy.R")
daily_k <- 5
monthly_k <- 1

# 1. China EPU data (monthly from 1951-1 on)
CN_EPU <- read_excel("data2/China_Mainland_Paper_EPU.xlsx", sheet = "EPU 2000 onwards",
                     col_types = c("numeric", "numeric", "numeric",
                                   "skip", "skip", "skip")) %>% 
  mutate(date = ym(paste(year, month, sep = "-"))) %>% 
  mutate(EPU_cn_lag1 = lag(EPU, n = monthly_k))
cn_epu <- ym_to_daily(CN_EPU)
names(cn_epu)[1] <- "cn_epu"


Global_EPU <- read_excel("data2/Global_EPU.xlsx",
                     col_types = c("numeric", "numeric", "numeric")) %>% 
  rename(year = Year, month = Month, gepu = GEPU_ppp) %>%
  #mutate(date = ym(paste(year, month, sep = "-"))) %>% 
  mutate(EPU_global_lag1 = lag(gepu, n = monthly_k))
global_epu <- ym_to_daily(Global_EPU )
names(global_epu)[1] <- "global_epu"


Global_GPR <- read_excel("data2/global_gpr.xls", sheet = 'Sheet3',
                         col_types = c("date", "numeric")) %>% 
  rename(gpr = GPR) %>%
  mutate(GPR_lag1 = lag(gpr, n = monthly_k)) %>% 
  mutate(year = year(date), month=month(date))
global_gpr <- ym_to_daily(Global_GPR )
#names(global_gpr)[1] <- "global_gpr"

Global_EWI <- read_excel("data2/ECONOMIC WEAKNESS INDEX.xlsx") %>% 
  rename(ewi = EWI) %>%
  #mutate(date = ym(paste(year, month, sep = "-"))) %>% 
  mutate(ewi_lag1 = lag(ewi, n = daily_k)) 
Global_EWI$date <- ymd(Global_EWI$date)
as.data.frame(Global_EWI)
global_ewi <- pad_by_time(Global_EWI, .by = "day", .fill_na_direction = "down")
#global_gpr <- ym_to_daily(Global_GPR )
#names(global_gpr)[1] <- "global_gpr"

Global_WIP <- read_excel("data2/World Industrial Production.xlsx") %>% 
  rename(wip = WIP) %>%
  #mutate(date = ym(paste(year, month, sep = "-"))) %>% 
  mutate(wip_lag1 = lag(wip, n = monthly_k)) %>% mutate(year = year(date), month=month(date))
Global_EWI$date <- ymd(Global_EWI$date)
global_wip <- ym_to_daily(Global_WIP )
#names(global_gpr)[1] <- "global_gpr"

Global_RCPF <- read_excel("data2/Real Commodity Price Factor.xlsx") %>% 
  rename(rcpf = RCPF) %>%
  #mutate(date = ym(paste(year, month, sep = "-"))) %>% 
  mutate(RCPF_lag1 = lag(rcpf, n = monthly_k)) %>% mutate(year = year(date), month=month(date))
global_rcpf <- ym_to_daily(Global_RCPF )
#names(global_gpr)[1] <- "global_gpr"

Global_GECON <- read_excel("data2/Global Economic Conditions (GECON) indicator.xlsx") %>% 
  rename(gecon = GECON) %>%
  #mutate(date = ym(paste(year, month, sep = "-"))) %>% 
  mutate(GECON_lag1 = lag(gecon, n = monthly_k)) 
global_gecon <- ym_to_daily(Global_GECON)
#names(global_gpr)[1] <- "global_gpr"

cn_CPI1 <- read_excel("data2/cpi.xls",  col_types = c("date", "numeric")) %>% 
  rename(cpi = CPI) 
cpi.xts <- xts(cn_CPI1$cpi, order.by = cn_CPI1$date) %>% diff()
cn_CPI <- as.tibble(cbind(cn_CPI1$date, as.data.frame(cpi.xts)))
names(cn_CPI) <- c('date', 'cpi')
 cn_CPI <- cn_CPI %>% 
#   #mutate(date = ym(paste(year, month, sep = "-"))) %>% 
   mutate(CPI_lag1 = lag(cpi, n = monthly_k)) %>% 
   mutate(year = year(date), month=month(date))
cn_cpi <- ym_to_daily(cn_CPI)

cn_GIP <- read_excel("data2/GIP.xls",  col_types = c("date", "numeric")) %>% 
  rename(gip = GIP) %>%
  #mutate(date = ym(paste(year, month, sep = "-"))) %>% 
  mutate(GIP_lag1 = lag(gip, n = monthly_k)) %>% 
  mutate(year = year(date), month=month(date))
cn_gip <- ym_to_daily(cn_GIP)

cn_M11 <- read_excel("data2/m1.xlsx",  col_types = c("date", "numeric")) %>% 
  rename(m1 = M1) 
m1.xts <- xts(cn_M11$m1, order.by = cn_M11$date) %>% diff()
cn_M1 <- as.tibble(cbind(cn_M11$date, as.data.frame(m1.xts)))
names(cn_M1) <- c('date', 'm1')
 cn_M1 <- cn_M1 %>% 
#   #mutate(date = ym(paste(year, month, sep = "-"))) %>% 
   mutate(M1_lag1 = lag(m1, n = monthly_k)) %>% 
   mutate(year = year(date), month=month(date))
cn_m1 <- ym_to_daily(cn_M1)

cn_PMI1 <- read_excel("data2/pmi.xls",  col_types = c("date", "numeric")) %>% 
  rename(pmi = PMI) %>% mutate(date = rev(date), pmi = rev(pmi))
pmi.xts <- xts(cn_PMI1$pmi, order.by = cn_PMI1$date) %>% diff()
cn_PMI <- as.tibble(cbind(cn_PMI1$date, as.data.frame(pmi.xts)))
names(cn_PMI) <- c('date', 'pmi')
cn_PMI <- cn_PMI %>% 
 # mutate(date = rev(date), pmi = rev(pmi)) %>% 
  #mutate(date = ym(paste(year, month, sep = "-"))) %>% 
  mutate(pmi_lag1 = lag(pmi, n = monthly_k)) %>% 
  mutate(year = year(date), month=month(date))
cn_pmi <- ym_to_daily(cn_PMI)


cn_GDP1 <- read_excel("data2/GDP.xls",  col_types = c("date", "numeric")) %>% 
  rename(gdp = GDP) %>% mutate(date = rev(date), gdp = rev(gdp))
gdp.xts <- xts(cn_GDP1$gdp, order.by = cn_GDP1$date) %>% diff()
cn_GDP <- as.tibble(cbind(cn_GDP1$date, as.data.frame(gdp.xts)))
names(cn_GDP) <- c('date', 'gdp')
cn_GDP <- cn_GDP %>% 
  #mutate(date = ym(paste(year, month, sep = "-"))) %>% 
  mutate(GDP_lag1 = lag(gdp, n = monthly_k)) %>% 
  mutate(year = year(date), month=month(date))
cn_gdp <- ym_to_daily(cn_GDP)


cn_PPI <- read_excel("data2/PPI.xls",  col_types = c("date", "numeric")) %>% 
  rename(ppi = PPI) %>%
  #mutate(date = ym(paste(year, month, sep = "-"))) %>% 
  mutate(ppi_lag1 = lag(ppi, n = monthly_k)) %>% 
  mutate(year = year(date), month=month(date))
cn_ppi <- ym_to_daily(cn_PPI)


cn_OVX <- read_excel("data2/OVX.xls",  col_types = c("text", "numeric")) %>% 
  rename(ovx = OVX) %>% mutate(date = mdy(date)) %>% 
  #mutate(date = ym(paste(year, month, sep = "-"))) %>% 
  mutate(OVX_lag1 = lag(ovx, n = 1)) 
oil_ovx <- cn_OVX

cn_PEMV <- read_excel("data2/PEMV.xlsx") %>% 
  mutate(date = ym(paste(year, month, sep = "-"))) %>% 
  mutate(PEMV_lag1 = lag(pemv, n = monthly_k)) %>% 
  mutate(year = year(date), month=month(date))
g_pemv <- ym_to_daily(cn_PEMV)

cn_iEMV <- read_excel("data2/IDEMV.xls") %>% 
  mutate(date = ymd(paste(year, month, day, sep = "-"))) %>% 
  mutate(IDEMV_lag1 = lag(infect_emv, n = 1)) %>% 
  select(4,5,6)
g_iemv <- cn_iEMV

cn_CEMV <- read_excel("data2/CEMV.xlsx") %>% 
  mutate(date = ym(paste(year, month, sep = "-"))) %>% 
  mutate(cemv_lag1 = lag(cemv, n = monthly_k)) %>% 
  mutate(year = year(date), month=month(date))
g_cemv <- ym_to_daily(cn_CEMV)


cn_OEMV <- read_excel("data2/oemv.xls") %>% 
  mutate(date = ym(paste(year, month, sep = "-"))) %>% 
  mutate(OEMV_lag1 = lag(oemv, n = monthly_k)) %>% 
  mutate(year = year(date), month=month(date))
g_oemv <- ym_to_daily(cn_OEMV)

cn_gpr <- read_excel("data2/global_gpr.xls",  sheet = 'Sheet2', col_types = c("date", "numeric"))
gpr.xts <- xts(cn_gpr$GPR, order.by = cn_gpr$date) %>% diff()
cn_gpr <- as.tibble(cbind(cn_gpr$date, as.data.frame(gpr.xts)))
names(cn_gpr) <- c('date', 'gpr')
cn_gpr <- cn_gpr %>% 
  #   #mutate(date = ym(paste(year, month, sep = "-"))) %>% 
  mutate(gpr_lag1 = lag(gpr, n = monthly_k)) %>% 
  mutate(year = year(date), month=month(date))
gpr <- ym_to_daily(cn_gpr)
